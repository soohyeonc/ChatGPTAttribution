#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
  string str = to_string(n);
  for (int i = 0; i < str.length() - 1; i++) {
    if (str[i] > str[i+1]) {
      return false;
    }
  }
  return true;
}

long long last_tidy_number(long long n) {
  while (!is_tidy(n)) {
    n--;
  }
  return n;
}

int main() {
  int T;
  cin >> T;
  for (int i = 1; i <= T; i++) {
    long long N;
    cin >> N;
    long long ans = last_tidy_number(N);
    cout << "Case #" << i << ": " << ans << endl;
  }
  return 0;
}
