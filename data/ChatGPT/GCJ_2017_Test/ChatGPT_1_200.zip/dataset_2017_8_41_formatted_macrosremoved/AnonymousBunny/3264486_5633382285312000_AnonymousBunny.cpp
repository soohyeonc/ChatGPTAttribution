#include <bits/stdc++.h>
using namespace std;

long long getTidyNumber(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = len - 2; i >= 0; i--) {
        if (s[i] > s[i + 1]) {
            s[i]--;
            for (int j = i + 1; j < len; j++) {
                s[j] = '9';
            }
        }
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << getTidyNumber(n) << endl;
    }
    return 0;
}
