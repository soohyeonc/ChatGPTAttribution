#include <bits/stdc++.h>
using namespace std;

string solve(string s) {
    int n = s.length();
    for (int i = n - 1; i > 0; i--) {
        if (s[i] < s[i - 1]) {
            s[i - 1]--;
            for (int j = i; j < n; j++) {
                s[j] = '9';
            }
        }
    }
    if (s[0] == '0') {
        s = s.substr(1);
    }
    return s;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string n;
        cin >> n;
        cout << "Case #" << t << ": " << solve(n) << endl;
    }
    return 0;
}
