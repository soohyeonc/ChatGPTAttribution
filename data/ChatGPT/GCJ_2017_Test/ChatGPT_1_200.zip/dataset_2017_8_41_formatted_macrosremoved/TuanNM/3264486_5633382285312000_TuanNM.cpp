#include <bits/stdc++.h>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        while (!is_tidy(n)) {
            n--;
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
