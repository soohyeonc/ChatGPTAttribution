#include<bits/stdc++.h>
using namespace std;

string makeTidy(string s) {
    int n = s.length();
    for (int i = n - 1; i > 0; i--) {
        if (s[i] < s[i - 1]) {
            s[i - 1]--;
            for (int j = i; j < n; j++) s[j] = '9';
        }
    }
    int i = 0;
    while (s[i] == '0') i++;
    return s.substr(i);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string s;
        cin >> s;
        cout << "Case #" << t << ": " << makeTidy(s) << endl;
    }
    return 0;
}
