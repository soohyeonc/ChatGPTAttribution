#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    string s = to_string(n);
    int i = s.size() - 1;
    while (i > 0 && s[i - 1] <= s[i]) {
        i--;
    }
    while (i > 0 && s[i - 1] > s[i]) {
        s[i - 1]--;
        i--;
    }
    for (int j = i; j < s.size(); j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = solve(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
