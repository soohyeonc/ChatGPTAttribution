#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long solve(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i = 1;
    while (i < s.length() && s[i] >= s[i-1]) {
        i++;
    }
    while (i > 0 && s[i-1] == '0') {
        i--;
    }
    s[i-1]--;
    for (i = i; i < s.length(); i++) {
        s[i] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
