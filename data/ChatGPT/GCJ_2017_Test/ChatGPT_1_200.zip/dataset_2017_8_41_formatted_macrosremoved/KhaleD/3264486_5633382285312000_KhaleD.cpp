#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
  string str = to_string(n);
  for (int i = 0; i < str.size() - 1; i++) {
    if (str[i] > str[i+1]) {
      return false;
    }
  }
  return true;
}

long long find_last_tidy(long long n) {
  while (!is_tidy(n)) {
    n--;
  }
  return n;
}

int main() {
  int t;
  cin >> t;
  for (int i = 1; i <= t; i++) {
    long long n;
    cin >> n;
    cout << "Case #" << i << ": " << find_last_tidy(n) << endl;
  }
  return 0;
}
