#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long get_last_tidy(long long n) {
    long long ans = n;
    for (long long i = n; i > 0; i--) {
        if (is_tidy(i)) {
            ans = i;
            break;
        }
    }
    return ans;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = get_last_tidy(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
