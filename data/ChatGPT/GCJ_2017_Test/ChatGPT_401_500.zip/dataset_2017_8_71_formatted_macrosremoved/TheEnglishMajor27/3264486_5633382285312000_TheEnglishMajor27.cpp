#include <iostream>
#include <string>
using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;

        long long left = 1, right = N;
        long long ans = -1;
        while (left <= right) {
            long long mid = (left + right) / 2;
            if (isTidy(mid)) {
                ans = mid;
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
