#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long num) {
    string s = to_string(num);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long find_tidy(long long N) {
    if (is_tidy(N)) {
        return N;
    }
    string s = to_string(N);
    int i = s.length() - 1;
    while (i > 0 && s[i] < s[i-1]) {
        i--;
    }
    if (i == 0) {
        return find_tidy(stoll(string(s.length() - 1, '9')));
    }
    s[i-1]--;
    for (int j = i; j < s.length(); j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long result = find_tidy(N);
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
