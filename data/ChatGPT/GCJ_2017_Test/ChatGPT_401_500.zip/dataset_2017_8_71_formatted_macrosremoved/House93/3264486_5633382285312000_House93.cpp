#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 0; i < len - 1; i++) {
        if (s[i] > s[i + 1]) {
            return false;
        }
    }
    return true;
}

long long findLastTidy(long long n) {
    while (!isTidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = findLastTidy(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
