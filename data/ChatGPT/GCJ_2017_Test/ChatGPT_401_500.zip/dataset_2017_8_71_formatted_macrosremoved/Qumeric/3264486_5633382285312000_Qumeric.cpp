#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long num) {
    string s = to_string(num);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i = s.length() - 1;
    while (i > 0 && s[i-1] <= s[i]) {
        i--;
    }
    while (i > 0 && s[i-1] > s[i]) {
        s[i-1]--;
        i--;
    }
    for (int j = i + 1; j < s.length(); j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long last_tidy = find_last_tidy(n);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
