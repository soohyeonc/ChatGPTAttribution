#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long solve(long long n) {
    long long ans = n;
    while (!is_tidy(ans)) {
        ans--;
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        long long ans = solve(n);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
