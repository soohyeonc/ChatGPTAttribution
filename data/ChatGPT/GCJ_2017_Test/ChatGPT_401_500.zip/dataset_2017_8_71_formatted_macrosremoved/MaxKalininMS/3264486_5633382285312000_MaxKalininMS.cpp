#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    long long left = 1;
    long long right = n;
    long long result = n;
    while (left <= right) {
        long long mid = (left + right) / 2;
        if (is_tidy(mid)) {
            result = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return result;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        long long result = last_tidy_number(n);
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
