#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long solve(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i;
    for (i = s.length()-1; i >= 1; i--) {
        if (s[i] < s[i-1]) {
            break;
        }
    }
    if (i == 0) {
        return solve(n-1);
    }
    else {
        s[i-1]--;
        for (int j = i; j < s.length(); j++) {
            s[j] = '9';
        }
        return stoll(s);
    }
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = solve(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
