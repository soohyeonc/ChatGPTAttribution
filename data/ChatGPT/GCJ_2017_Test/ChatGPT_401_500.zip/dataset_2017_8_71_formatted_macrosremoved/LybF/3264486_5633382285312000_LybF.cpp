#include <iostream>
#include <string>
using namespace std;

bool is_tidy(string s) {
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i + 1]) {
            return false;
        }
    }
    return true;
}

string decrease(string s) {
    int i = s.length() - 1;
    while (s[i] == '0') {
        i--;
    }
    s[i]--;
    for (int j = i + 1; j < s.length(); j++) {
        s[j] = '9';
    }
    return s;
}

string solve(string s) {
    if (is_tidy(s)) {
        return s;
    } else {
        string s1 = decrease(s);
        return solve(s1);
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string N;
        cin >> N;
        string ans = solve(N);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
