#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.size(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    long long ans = n;
    for (long long i = n; i > 0; i--) {
        if (is_tidy(i)) {
            ans = i;
            break;
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long ans = find_last_tidy(N);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
