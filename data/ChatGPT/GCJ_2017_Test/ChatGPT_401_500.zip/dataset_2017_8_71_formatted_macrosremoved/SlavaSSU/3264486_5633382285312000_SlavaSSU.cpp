#include <bits/stdc++.h>
using namespace std;

long long getTidyNumber(long long n) {
    string s = to_string(n);
    int len = s.length();
    int i = len - 1;
    while (i > 0 && s[i - 1] <= s[i]) {
        i--;
    }
    while (i > 0 && s[i - 1] > s[i]) {
        s[i - 1] = s[i - 1] - 1;
        i--;
    }
    for (int j = i + 1; j < len; j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << getTidyNumber(n) << endl;
    }
    return 0;
}
