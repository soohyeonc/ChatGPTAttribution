#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string str = to_string(n);
    int len = str.length();
    for (int i = 1; i < len; i++) {
        if (str[i] < str[i - 1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << last_tidy_number(n) << endl;
    }
    return 0;
}
