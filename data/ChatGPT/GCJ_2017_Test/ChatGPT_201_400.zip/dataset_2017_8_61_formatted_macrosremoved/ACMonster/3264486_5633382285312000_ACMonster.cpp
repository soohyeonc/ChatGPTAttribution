#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    for (long long i = n; i > 0; i--) {
        if (is_tidy(i)) {
            return i;
        }
    }
    return 0;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long last_tidy = last_tidy_number(n);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
