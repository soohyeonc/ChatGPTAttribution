#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long findLastTidy(long long n) {
    if (isTidy(n)) {
        return n;
    }
    string s = to_string(n);
    int len = s.length();
    int i = 1;
    while (i < len && s[i] >= s[i-1]) {
        i++;
    }
    while (i > 0 && s[i-1] == '0') {
        i--;
    }
    if (i == 0) {
        s = string(len-1, '9');
    } else {
        s[i-1]--;
        for (int j = i; j < len; j++) {
            s[j] = '9';
        }
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long result = findLastTidy(N);
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
