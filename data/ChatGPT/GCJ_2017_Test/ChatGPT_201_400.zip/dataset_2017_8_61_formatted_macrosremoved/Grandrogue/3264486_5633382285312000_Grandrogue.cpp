#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int pos = 0;
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            pos = i;
            break;
        }
    }
    s[pos] -= 1;
    for (int i = pos + 1; i < s.length(); i++) {
        s[i] = '9';
    }
    return last_tidy(stoll(s));
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        long long ans = last_tidy(n);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
