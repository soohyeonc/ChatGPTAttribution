#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.size(); i++) {
        if (s[i] < s[i - 1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i = 1;
    while (i < s.size() && s[i] >= s[i - 1]) {
        i++;
    }
    while (i > 1 && s[i - 1] == '0') {
        i--;
    }
    s[i - 1]--;
    for (int j = i; j < s.size(); j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = last_tidy_number(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
