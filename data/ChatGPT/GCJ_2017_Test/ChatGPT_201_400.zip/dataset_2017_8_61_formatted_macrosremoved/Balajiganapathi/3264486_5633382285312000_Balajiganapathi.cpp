#include <iostream>
#include <string>

using namespace std;

bool is_tidy(const string& s) {
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

string solve(const string& s) {
    if (is_tidy(s)) {
        return s;
    }
    string ans(s.length(), '9');
    for (int i = s.length() - 1; i > 0; i--) {
        if (s[i] < s[i-1]) {
            s[i-1]--;
            for (int j = i; j < s.length(); j++) {
                s[j] = '9';
            }
        }
    }
    return s[0] == '0' ? s.substr(1) : s;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string s;
        cin >> s;
        string ans = solve(s);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
