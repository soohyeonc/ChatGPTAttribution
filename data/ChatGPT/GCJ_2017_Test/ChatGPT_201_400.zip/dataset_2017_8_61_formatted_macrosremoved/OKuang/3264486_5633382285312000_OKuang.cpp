#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    while (!is_tidy(n)) {
        int i = 0;
        while (i < to_string(n).length() - 1 && to_string(n)[i] <= to_string(n)[i+1]) {
            i++;
        }
        n = stoll(to_string(n).substr(0, i+1) + string(to_string(n).length() - i - 1, '9'));
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long last_tidy = find_last_tidy(N);
        cout << "Case #" << t << ": " << last_tidy << endl;
    }
    return 0;
}
