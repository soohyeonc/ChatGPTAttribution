#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    long long left = 1, right = n;
    while (left < right) {
        long long mid = (left + right) / 2;
        if (is_tidy(mid)) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    return left - 1;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        long long last_tidy = find_last_tidy(n);
        cout << "Case #" << t << ": " << last_tidy << endl;
    }
    return 0;
}
