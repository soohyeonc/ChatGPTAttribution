#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <sstream>
#include <string>
#define _repargs(_1,_2,_3,name,...) name
#define _rep(i,n) repi(i,0,n)
#define repi(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define rep(...) _repargs(__VA_ARGS__,repi,_rep,)(__VA_ARGS__)
#define all(x) (x).begin(),(x).end()
#define mod 1000000007
#define inf 2000000007
#define mp make_pair
#define pb push_back
typedef long long ll;
using namespace std;
template <typename T>
inline void output(T a, int p = 0) {
    if(p) cout << fixed << setprecision(p)  << a << "\n";
    else cout << a << "\n";
}
// end of template

void gcjout(int index) {
    cout << "Case #" << index + 1 << ": ";
}


int main() {
    cin.tie(0);
    ios::sync_with_stdio(0);
    // source code

    int T;
    cin >> T;
    rep(t, T) {
        int N;
        cin >> N;
        vector<int> even, odd;
        rep(i, N){
            int a;
            cin >> a;
            if(i % 2 == 0) even.pb(a);
            else odd.pb(a);
        }
        sort(all(even));
        sort(all(odd));
        vector<int> A(N);
        rep(i, even.size()) A[i * 2] = even[i];
        rep(i, odd.size()) A[i * 2 + 1] = odd[i];
        gcjout(t);

        int ans = -1;
        rep(i, N - 1) {
            if(A[i] > A[i + 1]) {
                ans = i;
                break;
            }
        }
        if(ans == -1) output("OK");
        else output(ans);
    }


    return 0;
}
