#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <sstream>
#include <string>
#define _repargs(_1,_2,_3,name,...) name
#define _rep(i,n) repi(i,0,n)
#define repi(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define rep(...) _repargs(__VA_ARGS__,repi,_rep,)(__VA_ARGS__)
#define all(x) (x).begin(),(x).end()
#define mod 1000000007
#define inf 2000000007
#define mp make_pair
#define pb push_back
typedef long long ll;
using namespace std;
template <typename T>
inline void output(T a, int p = 0) {
    if(p) cout << fixed << setprecision(p)  << a << "\n";
    else cout << a << "\n";
}
// end of template
template <typename T> inline void voutput(T &v){
    rep(i, v.size()){
        if (i) cout << " " << v[i];
        else cout << v[i];
    }
    cout << endl;
}

void gcjout(int index) {
    cout << "Case #" << index + 1 << ": ";
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(0);
    // source code
    int T;
    cin >> T;
    rep(i, T){
        int N;
        cin >> N;
        vector<pair<int, int>> A(N);
        rep(i, N) {
            cin >> A[i].first;
            A[i].second = i;
        }
        sort(all(A));
        reverse(all(A));
        vector<string> ret;
        rep(i, A[0].first - A[1].first) {
            ret.pb(string(1, 'A' + A[0].second));
        }
        rep(i, 2, A.size()) {
            rep(j, A[i].first) {
                ret.pb(string(1, 'A' + A[i].second));
            }
        }

        rep(i, A[1].first) {
            string s = string(1, 'A' + A[0].second) + string(1, 'A' + A[1].second);
            ret.pb(s);
        }
        gcjout(i);
        voutput(ret);
    }

    return 0;
}
