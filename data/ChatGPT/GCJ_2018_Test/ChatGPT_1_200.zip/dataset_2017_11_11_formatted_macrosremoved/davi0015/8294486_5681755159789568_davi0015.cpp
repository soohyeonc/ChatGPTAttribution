#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <map>
#include <queue>
#include <ctime>
#include <cmath>

using namespace std;

#define forn(I,N) for (int I=0; I<N; I++)
#define fornd(I,N) for (int I=N-1; I>=0; I--)
#define forab(I,A,B) for (int I=A; I<=B; I++)
#define forabd(I,A,B) for (int I=B; I>=A; I--)
#define FOREACH(I,A) for (__typeof__(A)::iterator I=A.begin(); I<A.end(); I++)
#define pb push_back
#define mp make_pair

typedef long long int ll;

int main() {
  int T;
  cin >> T;

  forn(i, T) {
    int N;
    cin >> N;

    vector<int> P(N);
    int Pnum = 0;

    forn(j, N) {
      cin >> P[j];
      Pnum += P[j];
    }

    cout << "Case #" << i + 1 << ":";

    while (Pnum > 0) {
      int index = 0;
      forn(j, N) {
        if (P[j] > P[index]) {
          index = j;
        }
      }
      P[index]--;
      Pnum--;

      cout << " " << (char)('A' + index);

      index = 0;
      forn(j, N) {
        if (P[j] > P[index]) {
          index = j;
        }
      }
      P[index]--;
      Pnum--;

      int temp = index;
      index = 0;
      forn(j, N) {
        if (P[j] > P[index]) {
          index = j;
        }
      }
      if (P[index] * 2 <= Pnum) {
        cout << (char)('A' + temp);
      } else {
        P[temp]++;
        Pnum++;
      }
    }

    cout << endl;
  }

  return 0;
}
