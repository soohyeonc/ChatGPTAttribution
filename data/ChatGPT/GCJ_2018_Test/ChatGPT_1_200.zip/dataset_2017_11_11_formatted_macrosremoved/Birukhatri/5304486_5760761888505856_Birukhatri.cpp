#include <memory.h>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <climits>
#include <cctype>
#include <cstring>
#include <climits>
#include <cmath>
#include <vector>
#include <string>
#include <memory>
#include <numeric>
#include <limits>
#include <functional>
#include <tuple>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iostream>

using namespace std;

#define PROFILE_START(i)    clock_t start##i = clock()
#define PROFILE_STOP(i)     fprintf(stderr, "elapsed time (" #i ") = %f\n", double(clock() - start##i) / CLOCKS_PER_SEC)

#ifndef M_PI
#define M_PI       3.14159265358979323846   // pi
#define M_1_PI     0.318309886183790671538  // 1/pi
#define M_SQRT2    1.41421356237309504880   // sqrt(2)
#endif

typedef long long           ll;
typedef unsigned long long  ull;

int main(void) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        ll K, N;
        cin >> K >> N;

        map<ll, ll> M;
        M.emplace(K, 1ll);

        while (N > M.rbegin()->second) {
            ll a = M.rbegin()->first;
            ll b = M.rbegin()->second;
            M.erase(--M.end());

            M[a / 2] += b;
            M[(a - 1) / 2] += b;

            N -= b;
        }

        ll a = M.rbegin()->first;

        cout << "Case #" << t << ": " << a / 2 << " " << (a - 1) / 2 << endl;
    }

    return 0;
}
