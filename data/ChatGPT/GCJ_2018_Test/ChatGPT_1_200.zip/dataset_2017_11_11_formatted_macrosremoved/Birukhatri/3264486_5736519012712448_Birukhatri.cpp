#include <memory.h>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <climits>
#include <cctype>
#include <cstring>
#include <climits>
#include <cmath>
#include <vector>
#include <string>
#include <memory>
#include <numeric>
#include <limits>
#include <functional>
#include <tuple>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iomanip>
#include <iostream>

using namespace std;

#define PROFILE_START(i)    clock_t start##i = clock()
#define PROFILE_STOP(i)     fprintf(stderr, "elapsed time (" #i ") = %f\n", double(clock() - start##i) / CLOCKS_PER_SEC)

#ifndef M_PI
#define M_PI       3.14159265358979323846   // pi
#define M_1_PI     0.318309886183790671538  // 1/pi
#define M_SQRT2    1.41421356237309504880   // sqrt(2)
#endif

typedef long long           ll;
typedef unsigned long long  ull;

int main(void) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<int> V0, V1;
        V0.reserve(N);
        V1.reserve(N);
        for (int i = 0; i < N; i++) {
            int x;
            cin >> x;

            if ((i & 1) == 0)
                V0.push_back(x);
            else
                V1.push_back(x);
        }

        sort(V0.begin(), V0.end());
        sort(V1.begin(), V1.end());

        if (V0.size() > V1.size())
            V1.push_back(INT_MAX);

        vector<int> V;
        V.reserve(N + 2);
        for (int i = 0; i < (int)V0.size(); i++) {
            V.push_back(V0[i]);
            V.push_back(V1[i]);
        }

        int ans = -1;
        for (int i = 0; i < (int)V.size() - 1; i++) {
            if (V[i] > V[i + 1]) {
                ans = i;
                break;
            }
        }

        cout << setprecision(9) << "Case #" << t << ": ";

        if (ans < 0)
            cout << "OK";
        else
            cout << ans;

        cout << endl;
    }

    return 0;
}
