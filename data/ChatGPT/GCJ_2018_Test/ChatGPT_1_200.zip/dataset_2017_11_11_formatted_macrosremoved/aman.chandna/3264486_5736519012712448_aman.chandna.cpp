#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string.h>
#include <strings.h>
#include <string>
#include <algorithm>
#include <vector>
#include <set>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <cmath>
#include <map>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <functional>
#include <numeric>
#include <utility>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <climits>
#include <assert.h>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int,int> ii;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> int2;
typedef pair<float, float> float2;
typedef pair<ull, ull> ull2;

#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(),(c).end()
#define tr(s,i) for ( __typeof((s).begin()) i = ((s).begin())   ; i != (s).end(); ++i)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
#define mp(a,b) make_pair(a,b)
#define del(s,x) do {__typeof((s).begin()) abcde=(s).find(x); if(abcde !=(s).end()) s.erase(abcde); } while(0);
#define del2(s,x) do {__typeof((s).begin()) abcde=find(all(s),x); if(abcde !=(s).end()) s.erase(abcde); } while(0);

#define FOR(i,a,b) for(int i=int(a); i<int(b); ++i)

int main() {
  int T;
  scanf("%d", &T);

  FOR (test, 1, T+1) {

    int n; scanf("%d", &n);
    vi even, odd;
    FOR(i,0,n) {
      int val; scanf("%d",&val);
      if (i%2 == 0) even.pb(val);
      else odd.pb(val);
    }
    sort(all(even));
    sort(all(odd));
    int idx = 0;
    FOR(i,0,n/2) {
      if(even[i] > odd[i]) break;
      idx++;
      if(i+1 >= even.size()) break;
      if(odd[i] > even[i+1]) break;
      idx++;
    }
    if(idx < n-1)
      printf("Case #%d: %d\n", test, idx);
    else
      printf("Case #%d: OK\n", test);
  }
  return 0;
}
