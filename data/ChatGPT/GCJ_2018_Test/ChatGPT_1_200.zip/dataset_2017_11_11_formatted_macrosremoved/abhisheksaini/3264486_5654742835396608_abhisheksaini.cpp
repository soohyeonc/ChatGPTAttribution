#include <bits/stdc++.h>
//#define SYNC ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
#define gc getchar_unlocked
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define ll long long
#define ull unsigned long long
#define si(x)	scanf("%d",&x)
#define sl(x)	scanf("%lld",&x)
#define ss(s)	scanf("%s",s)
#define pi(x)	printf("%d\n",x)
#define pl(x)	printf("%lld\n",x)
#define ps(s)	printf("%s\n",s)
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, a) for(auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
int main()
{
	//SYNC
	int t;
	cin>>t;
	int a;
	while(t--)
	{
		set<pair<int,int> > st1;
		//set<pair<int,int> > st2;
		cin>>a;
		int j,k;
		int m,n;
		pair<int,int> p;
		/*while(m<=13)
		{
			n=12;
			while(n<=14)
			{
				p.first=m;
				p.second=n;
				st2.insert(p);
				n++;
			}
			m++;
		}*/
		if(a==20){
		m=8;	n=13;
		cout<<m<<" "<<n<<endl;
		cout.flush();
		cin>>j>>k;
		if(j==-1&&k==-1)	return 0;
		else
		st1.insert(mp(j,k));

		while(1)
		{
			if(!(m==12&&n==13))
			{
				//cout<<"fck2 "<<j<<" "<<k<<"\n";
				while(!((st1.find(mp(m-1,n-1))!=st1.end()) && (st1.find(mp(m-1,n))!=st1.end()) && (st1.find(mp(m-1,n+1))!=st1.end())))
				{
					cout<<m<<" "<<n<<endl;
					cout.flush();
					cin>>j>>k;
					if(j==0&&k==0)	break;
					if(j==-1&&k==-1)	return 0;
					else
					st1.insert(mp(j,k));
				//cout<<"fck "<<j<<" "<<k<<"\n";
				}
			}
			else
			{
				//cout<<"fck1\n";
				while(!((st1.find(mp(m-1,n-1))!=st1.end()) && (st1.find(mp(m-1,n))!=st1.end()) &&	(st1.find(mp(m-1,n+1))!=st1.end()) && (st1.find(mp(m,n-1))!=st1.end()) && (st1.find(mp(m,n))!=st1.end()) && (st1.find(mp(m,n+1))!=st1.end()) && (st1.find(mp(m+1,n-1))!=st1.end()) && (st1.find(mp(m+1,n))!=st1.end()) && (st1.find(mp(m+1,n+1))!=st1.end())))
				{
					cout<<m<<" "<<n<<endl;
					cout.flush();
					cin>>j>>k;
					if(j==0&&k==0)	break;
					if(j==-1&&k==-1)	return 0;
					else
					st1.insert(mp(j,k));
				}
			}
			m+=1;
			if(j==0&&k==0)	break;
		}	}
		else
		{
			m=8;	n=13;
		cout<<m<<" "<<n<<endl;
		cout.flush();
		cin>>j>>k;
		if(j==-1&&k==-1)	return 0;
		else
		st1.insert(mp(j,k));

		while(1)
		{
			if(!(m==72&&n==13))
			{
				//cout<<"fck2 "<<j<<" "<<k<<"\n";
				while(!((st1.find(mp(m-1,n-1))!=st1.end()) && (st1.find(mp(m-1,n))!=st1.end()) && (st1.find(mp(m-1,n+1))!=st1.end())))
				{
					cout<<m<<" "<<n<<endl;
					cout.flush();
					cin>>j>>k;
					if(j==0&&k==0)	break;
					if(j==-1&&k==-1)	return 0;
					else
					st1.insert(mp(j,k));
				//cout<<"fck "<<j<<" "<<k<<"\n";
				}
			}
			else
			{
				//cout<<"fck1\n";
				while(!((st1.find(mp(m-1,n-1))!=st1.end()) && (st1.find(mp(m-1,n))!=st1.end()) &&	(st1.find(mp(m-1,n+1))!=st1.end()) && (st1.find(mp(m,n-1))!=st1.end()) && (st1.find(mp(m,n))!=st1.end()) && (st1.find(mp(m,n+1))!=st1.end()) && (st1.find(mp(m+1,n-1))!=st1.end()) && (st1.find(mp(m+1,n))!=st1.end()) && (st1.find(mp(m+1,n+1))!=st1.end())))
				{
					cout<<m<<" "<<n<<endl;
					cout.flush();
					cin>>j>>k;
					if(j==0&&k==0)	break;
					if(j==-1&&k==-1)	return 0;
					else
					st1.insert(mp(j,k));
				}
			}
			m+=1;
			if(j==0&&k==0)	break;
		}
		}
	}
	return 0;
}
