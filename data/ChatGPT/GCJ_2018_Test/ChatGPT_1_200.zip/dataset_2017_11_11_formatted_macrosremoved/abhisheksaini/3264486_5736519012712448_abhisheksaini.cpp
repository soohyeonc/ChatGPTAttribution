#include <bits/stdc++.h>
#define SYNC ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
#define gc getchar_unlocked
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define ll long long
#define ull unsigned long long
#define si(x)	scanf("%d",&x)
#define sl(x)	scanf("%lld",&x)
#define ss(s)	scanf("%s",s)
#define pi(x)	printf("%d\n",x)
#define pl(x)	printf("%lld\n",x)
#define ps(s)	printf("%s\n",s)
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, a) for(auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
int main()
{
	SYNC
	int t;
	scanf("%d",&t);
	int t1=0;
	while(t--)
	{
		t1++;
		int n;
		scanf("%d",&n);
		long arr[n];
		int i=0;
		for(i=0;i<n;i++)
			scanf("%ld",&arr[i]);
		int j=0;
		for(i=0;i<n-2;i++)
		{
			for(j=0;j<n-i-2;j++)
			{
				if(arr[j]>arr[j+2])
				{
					int tmp=arr[j];
					arr[j]=arr[j+2];
					arr[j+2]=tmp;
				}
			}
		}
		for(i=0;i<n-1;i++)
		{
			if(arr[i]>arr[i+1])	break;
		}
		printf("Case #%d: ",t1);
		if(i==n-1)printf("OK\n");
		else
			printf("%d\n",i);
	}
	return 0;
}
