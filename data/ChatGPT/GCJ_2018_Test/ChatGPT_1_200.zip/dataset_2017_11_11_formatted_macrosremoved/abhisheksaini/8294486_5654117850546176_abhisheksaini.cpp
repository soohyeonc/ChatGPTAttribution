#include <bits/stdc++.h>
#define SYNC ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
#define gc getchar_unlocked
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define ll long long
#define ull unsigned long long
#define si(x)	scanf("%d",&x)
#define sl(x)	scanf("%lld",&x)
#define ss(s)	scanf("%s",s)
#define pi(x)	printf("%d\n",x)
#define pl(x)	printf("%lld\n",x)
#define ps(s)	printf("%s\n",s)
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, a) for(auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
int main()
{
	SYNC
	int t;
	cin>>t;
	ll a,b,n,c;
	string s;

	ll i;
	while(t--){
	cin>>a>>b>>n;
	c=(rand()%(b-a))+a+1;
	for(i=1;i<=n;i++)
	{
		cout<<c<<flush;
		getline(cin,s);
		if(s=="CORRECT")	break;
		else if(s=="TOO_SMALL")
		{
			c=(rand()%(b-c+1))+c;
			continue;
		}
		else if(s=="TOO_BIG")
			{
				c=(rand()%(c-a))+a+1;
				continue;
			}
		else if(s=="WRONG_ANSWER")
			return 0;
	}
	}
	return 0;
}
