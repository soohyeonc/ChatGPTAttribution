#include<iostream>
#include<iomanip>
#include<math.h>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<string>
#include<bitset>
#include<random>
#include<time.h>
#define INF 1000000000ll
#define MOD 1000000007ll
#define EPS 1e-10
#define REP(i,m) for(long long i=0; i<(ll)m; i++)
#define FOR(i,n,m) for(long long i=n; i<(ll)m; i++)
#define DUMP(a) for(long long dump=0; dump<(ll)a.size(); dump++) { cout<<a[dump]; if(dump!=(ll)a.size()-1) cout<<" "; else cout<<endl; }
#define ALL(v) v.begin(),v.end()
#define UNIQUE(v) sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end());
#define pb push_back
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
typedef long double ld;

int main() {
	ios::sync_with_stdio(false);
	ll T;
	cin>>T;
	REP(testcase,T) {
		ll n;
		cin>>n;
		vector<ll> v(n);
		REP(i,n) cin>>v[i];
		vector<ll> e;
		vector<ll> o;
		REP(i,n) {
			if(i%2==0) e.pb(v[i]);
			else o.pb(v[i]);
		}
		sort(ALL(e));
		sort(ALL(o));
		sort(ALL(v));
		vector<ll> v2;
		ll p1=0,p2=0;
		while(1) {
			bool upd=false;
			if(p1<(ll)e.size()) {
				upd=true;
				v2.pb(e[p1]);
				p1++;
			}
			if(p2<(ll)o.size()) {
				upd=true;
				v2.pb(o[p2]);
				p2++;
			}
			if(!upd) break;
		}
		bool hoge=false;
		REP(i,n) {
			if(v[i]!=v2[i]) {
				cout<<"Case #"<<testcase+1<<": "<<i<<endl;
				hoge=true;
				break;
			}
		}
		if(!hoge) cout<<"Case #"<<testcase+1<<": "<<"OK"<<endl;

	}
}
