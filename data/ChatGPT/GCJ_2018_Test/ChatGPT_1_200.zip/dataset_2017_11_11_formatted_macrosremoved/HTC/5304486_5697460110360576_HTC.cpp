#include<iostream>
#include<iomanip>
#include<math.h>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<string>
#include<bitset>
#include<random>
#include<time.h>
#define INF 1000000000ll
#define MOD 1000000007ll
#define EPS 1e-10
#define REP(i,m) for(long long i=0; i<(ll)m; i++)
#define FOR(i,n,m) for(long long i=n; i<(ll)m; i++)
#define DUMP(a) for(long long dump=0; dump<(ll)a.size(); dump++) { cout<<a[dump]; if(dump!=(ll)a.size()-1) cout<<" "; else cout<<endl; }
#define ALL(v) v.begin(),v.end()
#define UNIQUE(v) sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end());
#define pb push_back
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
typedef long double ld;

int main() {
	ios::sync_with_stdio(false);
	ll T;
	cin>>T;
	REP(testcase,T) {
		ll d;
		cin>>d;
		string s;
		cin>>s;
		ll c=0;
		REP(i,(ll)s.size()) if(s[i]=='S') c++;
		if(c>d) {
			cout<<"Case #"<<testcase+1<<": "<<"IMPOSSIBLE"<<endl;
		} else {
			vector<ll> cnt(30,0);
			ll cg=0;
			ll sum=0;
			REP(i,(ll)s.size()) {
				if(s[i]=='C') cg++;
				else {
					cnt[cg]++;
					sum+=(1ll<<cg);
				}
			}
			ll ans=0;
			ll p=29;
			while(sum>d) {
				if(cnt[p]==0) p--;
				else {
					ans++;
					cnt[p]--;
					if(p>0) cnt[p-1]++;
					sum-=(1ll<<p)/2;
				}
			}
			cout<<"Case #"<<testcase+1<<": "<<ans<<endl;
		}
	}
}
