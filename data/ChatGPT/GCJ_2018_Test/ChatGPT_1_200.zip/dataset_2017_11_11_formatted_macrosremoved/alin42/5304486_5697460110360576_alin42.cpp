#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<unsigned> vu;
typedef vector<ll> vll;
typedef vector<ull> vull;
typedef pair<int, int> pii;
typedef pair<unsigned, unsigned> puu;
typedef pair<ll, ll> pll;
typedef pair<ull, ull> pull;
typedef vector<string> vs;
#define pb push_back
#define ppb pop_back
#define be begin
#define all(x) (x).be(), (x).end()
#define fst first
#define fir first
#define sec second
#define mkp make_pair
#define brif(cond) if (cond) break
#define ctif(cond) if (cond) continue
#define retif(cond) if (cond) return
static inline void canhazfast() {ios_base::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);}
template<typename T> T gcd(T a, T b) {return b == 0 ? a : gcd(b, a%b);}
template<typename T> T extgcd(T a, T b, T &x, T &y)
{
    T x0 = 1, y0 = 0, x1 = 0, y1 = 1;
    while (b) {
        T q = a/b; a %= b; swap(a, b);
        x0 -= q*x1; swap(x0, x1);
        y0 -= q*y1; swap(y0, y1);
    }
    x = x0; y = y0; return a;
}

void solve(int tc)
{
    unsigned d, v = 0;
    char p[32];
    int n, x = 0, ans = 0;
    priority_queue<unsigned> q;

    scanf("%u%s", &d, p);
    n = strlen(p);
    for (int i = 0; i < n; ++i) {
        if (p[i] == 'C') {
            ++x;
        } else {
            v += 1U << x;
            q.push(1u << x);
        }
    }
    while (!q.empty() && d < v) {
        unsigned u = q.top();
        q.pop();
        u /= 2;
        v -= u;
        if (u > 1) q.push(u);
        ++ans;
    }
    printf("Case #%d: ", tc);
    if (d >= v) printf("%d\n", ans);
    else puts("IMPOSSIBLE");
}

int main()
{
    //canhazfast();

    int t;
    scanf("%d", &t);
    for (int i = 1; i <= t; ++i) solve(i);

    return 0;
}
