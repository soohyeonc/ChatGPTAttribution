#include <bits/stdc++.h>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef long double ld;
typedef complex<ld> cd;

typedef pair<int, int> pi;
typedef pair<ll,ll> pl;
typedef pair<double,double> pd;

typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pi> vpi;

template <class T> using Tree = tree<T, null_type, less<T>, rb_tree_tag,tree_order_statistics_node_update>;

#define FOR(i, a, b) for (int i=a; i<(b); i++)
#define F0R(i, a) for (int i=0; i<(a); i++)
#define FORd(i,a,b) for (int i = (b)-1; i >= a; i--)
#define F0Rd(i,a) for (int i = (a)-1; i >= 0; i--)

#define sz(x) (int)(x).size()
#define mp make_pair
#define pb push_back
#define f first
#define s second
#define lb lower_bound
#define ub upper_bound
#define all(x) x.begin(), x.end()

const int MOD = 1000000007;
const double PI = 4*atan(1);
const ll INF = 1e18;
const int MX = 100001;

void prin(int a) {
    cout << char('A'+a) << " ";
}

void prin(int a, int b) {
    cout << char('A'+a) << char('A'+b) << " ";
}

int main() {
    int T; cin >> T;
    F0R(i,T) {
        int N; cin >> N;
        set<pi> s;
        int lef = 0;
        F0R(j,N) {
            int x; cin >> x;
            lef += x;
            s.insert({x,j});
        }
        cout << "Case #" << (i+1) << ": ";
        while (lef) {
            if (sz(s) == 2) {
                F0R(i,s.rbegin()->f) prin(s.begin()->s,s.rbegin()->s);
                break;
            } else {
                pi x = *s.rbegin();
                prin(x.s);
                s.erase(x);
                x.f --; if (x.f) s.insert(x);
                lef --;
            }
        }
        cout << "\n";
    }
}

// read the question correctly (is y a vowel?)
// look out for SPECIAL CASES (n=1?) and overflow (ll vs int?)
