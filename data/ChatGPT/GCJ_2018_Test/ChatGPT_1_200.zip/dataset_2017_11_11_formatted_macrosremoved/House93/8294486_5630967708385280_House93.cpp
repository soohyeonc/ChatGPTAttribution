#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  for(int tt=1;tt<=T;tt++){
    cout<<"Case #"<<tt<<": ";
    int D,N;cin>>D>>N;
    double t=0.0;
    for(int i=0;i<N;i++){
      int K,S;cin>>K>>S;
      t=max(t,1.0*(D-K)/S);
    }
    cout<<fixed<<setprecision(9)<<D/t<<'\n';
  }

  return 0;
}
