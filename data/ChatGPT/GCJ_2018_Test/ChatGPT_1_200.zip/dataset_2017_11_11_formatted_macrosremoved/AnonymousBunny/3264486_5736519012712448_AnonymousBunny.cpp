#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl

int main() {
	int tc,n,cur;
	scanf("%d",&tc);
	for(int cn=1;cn<=tc;++cn) {
		vi v[2];
		int to=0;
		scanf("%d",&n);
		for(int i=0;i<n;++i) {
			scanf("%d",&cur);
			v[to].pb(cur);
			to^=1;
		}
		sort(v[0].begin(), v[0].end());
		sort(v[1].begin(), v[1].end());
		int len=v[0].size();
		v[0].pb(1e9+1);
		v[1].pb(1e9+1);
		bool can=1;
		int ans;
		for(int i=0;i<len;++i) {
			if(v[0][i]>v[1][i]) {
				ans=2*i;
				can=0;
				break;
			} else if(v[1][i]>v[0][i+1]) {
				ans=2*i+1;
				can=0;
				break;
			}
		}
		if (can) printf("Case #%d: OK\n",cn);
		else {

			printf("Case #%d: %d\n",cn,ans);
		}
	}
}
