#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl



int main() {
	int a,b,n,tc;
	string s;
	cin>>tc;
	while(tc--) {
		cin>>a>>b>>n;
		while(1) {
			int mid=a+(b+1-a)/2;
			cout<<mid<<endl;
			cin>>s;
			if(s=="CORRECT") break;
			else if(s=="TOO_SMALL") a=mid;
			else b=mid-1;
		}
	}

}
