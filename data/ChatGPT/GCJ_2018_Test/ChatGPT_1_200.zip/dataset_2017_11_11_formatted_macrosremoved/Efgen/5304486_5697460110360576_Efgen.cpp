#include <bits/stdc++.h>
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}

using namespace std;

ll calc_attack(string const&s){
    ll ret = 0, cur = 1;
    for(auto &e:s){
        if(e == 'C'){
            cur*=2;
        } else if(e=='S'){
            ret+=cur;
        } else assert(0);
    }
    return ret;
}

void solve(){
    ll d;
    cin >> d;
    string s;
    cin >> s;
    int ans = 0;
    for(;calc_attack(s) > d;++ans){
        for(int i=s.size()-1;i>=0;--i){
            if(i == 0){
                cout << "IMPOSSIBLE\n";
                return;
            }
            if(s[i] == 'S' && s[i-1] == 'C'){
                swap(s[i], s[i-1]);
                break;
            }
        }
    }
    cout << ans << "\n";
}

int main()
{
    #ifdef LOCAL_RUN
    freopen("inA.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0);
    int TTT; cin >> TTT;
    for(int cas = 1;cas<=TTT;++cas){
        cout << "Case #" << cas << ": ";

        solve();

        #ifdef LOCAL_RUN
        cout << flush;
        #endif
    }
    return 0;
}
