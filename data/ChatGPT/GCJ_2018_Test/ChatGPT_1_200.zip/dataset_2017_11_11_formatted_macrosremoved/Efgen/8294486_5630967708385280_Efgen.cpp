#include <bits/stdc++.h>
using namespace std;
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}

using fl = long double;

signed main()
{
    #ifdef LOCAL_RUN
    freopen("inC.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0); ios_base::sync_with_stdio(false);
    int TTT; cin >> TTT;
    for(int cas=1;cas<=TTT;++cas) {
    cout << "Case #" << cas << ": " ;

    int d, n;
    cin >> d >> n;
    fl max_tim = 1e-90;
    for(int i=0;i<n;++i){
        int x, v;
        cin >> x >> v;
        xmax(max_tim, (d-x)/(fl)v);
    }
    cout << fixed << setprecision(25) << d/max_tim << "\n";


    }
    return 0;
}
