#include <iostream>      // Input/Output
#include <iomanip>
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

const u64 MOD = 1000000007;

using namespace std;

struct H {
  i64 k;
  i64 s;

  bool operator<(const struct H &h) {
    return k > h.k || (k==h.k && s < h.s);
  }
};

void solve(i64 t) {
  i64 d,n;
  cin >> d >> n;

  H h[1010];

  for(i64 i=0;i<n;++i) cin >> h[i].k >> h[i].s;

  sort(h,h+n);

  double ti = 0.0;
  for(i64 i=0;i<n;++i) {
    ti = max(((double)(d-h[i].k))/((double)(h[i].s)), ti);
  }

  cout << fixed << setprecision(6) << "Case #" << t << ": " << ((double)d)/ti << "\n";
}

int main(void) {
  i64 t;
  cin >> t;

  for(i64 i=1;i<=t;++i) {
    solve(i);
  }

  return 0;
}
