#include <iostream> // includes cin to read from stdin and cout to write to stdout
#include <map>
#include <set>
#include <list>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cassert>
#include <cassert>
#include <math.h>
///LLONG_MAX,INT_MA
#define FOR(i,a,b) for(int i=(a),_b=(b);i<=_b;i++)
#define REP(i,n) FOR(i,0,(n)-1)
#define FORD(i,a,b) for(int i=(a),_b=(b);i>=_b;i--)
#define sz size()
#define FORA(i,c) REP(i,size(c))

#define itype(c) __typeof((c).begin())
#define FORE(e,c) for(itype(c) e=(c).begin();e!=(c).end();e++)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define SORT(x) sort(all(x))
#define REVERSE(x) reverse(all(x))
#define CLEAR(x,c) memset(x,c,sizeof(x))
#define amfor(Iterator, Container) 	for ( auto Iterator = begin(Container); (Iterator) != end(Container); ++(Iterator) )
#define ramfor(Iterator, Container) for ( auto Iterator = Container.rbegin(); (Iterator) != Container.rend(); ++(Iterator) )
template<class C, class E> inline bool contains(const C& container, const E& element) { return container.find(element) != container.end(); }
#define  NP(nn,ta,a,tb,b) struct nn : pair<ta,tb> { nn():pair<ta,tb>(){}; nn(ta pa,tb pb):pair<ta,tb>(pa,pb){} ta& a(){return first;} tb& b(){return second;} };
template<class T> inline void checkmin(T &a, T b) { if (b < a) a = b; }//asigna en a el minimo
template<class T> inline void checkmax(T &a, T b) { if (b > a) a = b; }//asigna en a el maximo


using namespace std; // since cin and cout are both in namespace std, this saves some text
long long a, b, n;
void Solve()
{
	long long p = (a + b) / 2;
	cout << p << endl;
	string ans;
	cin >> ans;
	while (ans != "CORRECT")
	{
		if (ans == "TOO_SMALL")
			a = p;
		else
			b = p;
		p = (a + b) / 2;
		cout << p<< endl;
		cin >> ans;
	}
}

int main()
{
	int t;
	cin >> t;
	REP(i, t)
	{
		cin >> a >> b;
		++b;
		cin >> n;

		Solve();
	}
	return 0;
}
