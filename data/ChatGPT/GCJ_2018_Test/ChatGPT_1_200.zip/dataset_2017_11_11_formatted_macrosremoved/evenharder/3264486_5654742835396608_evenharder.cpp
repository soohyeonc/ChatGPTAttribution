#include <iostream> // includes cin to read from stdin and cout to write to stdout
#include <map>
#include <set>
#include <list>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cassert>
#include <math.h>
#include <iomanip>
#include <limits>
#define FOR(i,a,b) for(int i=(a),_b=(b);i<=_b;i++)
#define REP(i,n) FOR(i,0,(n)-1)
#define FORD(i,a,b) for(int i=(a),_b=(b);i>=_b;i--)
#define sz size()
#define FORA(i,c) REP(i,size(c))

#define itype(c) __typeof((c).begin())
#define FORE(e,c) for(itype(c) e=(c).begin();e!=(c).end();e++)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define SORT(x) sort(all(x))
#define REVERSE(x) reverse(all(x))
#define CLEAR(x,c) memset(x,c,sizeof(x))
#define amfor(Iterator, Container) 	for ( auto Iterator = begin(Container); (Iterator) != end(Container); ++(Iterator) )
#define ramfor(Iterator, Container) for ( auto Iterator = Container.rbegin(); (Iterator) != Container.rend(); ++(Iterator) )
template<class C, class E> inline bool contains(const C& container, const E& element) { return container.find(element) != container.end(); }
#define  NP(nn,ta,a,tb,b) struct nn : pair<ta,tb> { nn():pair<ta,tb>(){}; nn(ta pa,tb pb):pair<ta,tb>(pa,pb){} ta& a(){return first;} tb& b(){return second;} };
template<class T> inline void checkmin(T &a, T b) { if (b < a) a = b; }//asigna en a el minimo
template<class T> inline void checkmax(T &a, T b) { if (b > a) a = b; }//asigna en a el maximo

using namespace std; // since cin and cout are both in namespace std, this saves some text
//ofstream oo("salida.txt");
long long d,n;
bool dataMap[300][300];
int xs, ys;
int Count(int xp,int yp)
{
	int res = 0;
	for (int x = -1; x <= 1; ++x)
	{
		for (int y = -1; y <= 1; ++y)
		{
			if (!dataMap[xp + x][yp + y])
				++res;
		}
	}
	return res;
}
void Find(int &xt, int &yt)
{
	int winner = -1;///busco muchos sin agujero (false)
	for (int x = 1; x < xs-1; ++x)
	{
		for (int y = 1; y < ys - 1; ++y)
		{
			int thisNotAgu = Count(x, y);
			if (thisNotAgu > winner)
			{
				xt = x;
				yt = y;
				winner = thisNotAgu;
				if (winner == 9)
					return;
			}
		}
	}

}
void Solve()
{
	int A;
	cin >> A;
	if (A == 20)
	{
		xs = 4;
		ys = 5;
	}
	else if(A == 200)
	{
		xs = 20;
		ys = 10;
	}
	else if (A == 10)
	{
		xs = 3;
		ys = 5;
	}
	//oo << "Size" << xs << " " << ys << endl;
	for (int x = 0; x < xs; ++x)
		for (int y = 0; y < ys; ++y)
			dataMap[x][y] = false;
	int cc = 0;
	while (true)
	{
		int xt, yt;
		Find(xt, yt);
		//oo << "Mando" << (xt + 1) << " " << (yt + 1) << endl;
		cout << (xt+1) << " " << (yt+1) << endl;
		++cc;
		int xr, yr;
		cin >> xr >> yr;
		//oo << "Lei " << xr << " " << yr << endl;
		if (xr == -1 && yr == -1)
			return;
		if (xr == 0 && yr == 0)
		{
			//oo << cc << endl;
			return;
		}
		dataMap[xr-1][yr-1] = true;
	}
}

int main()
{
	int totalCases;
	cin >> totalCases;
	cout << std::setprecision(15);
	cout << std::fixed;

	REP(theCase, totalCases)
	{
		Solve();
	}
	return 0;
}
