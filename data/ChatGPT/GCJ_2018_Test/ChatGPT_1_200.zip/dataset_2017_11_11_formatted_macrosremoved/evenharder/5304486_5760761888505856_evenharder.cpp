#include <iostream> // includes cin to read from stdin and cout to write to stdout
#include <map>
#include <set>
#include <list>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cassert>
#include <math.h>
#include <iomanip>
#include <limits>
#define FOR(i,a,b) for(int i=(a),_b=(b);i<=_b;i++)
#define REP(i,n) FOR(i,0,(n)-1)
#define FORD(i,a,b) for(int i=(a),_b=(b);i>=_b;i--)
#define sz size()
#define FORA(i,c) REP(i,size(c))

#define itype(c) __typeof((c).begin())
#define FORE(e,c) for(itype(c) e=(c).begin();e!=(c).end();e++)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define SORT(x) sort(all(x))
#define REVERSE(x) reverse(all(x))
#define CLEAR(x,c) memset(x,c,sizeof(x))
#define amfor(Iterator, Container) 	for ( auto Iterator = begin(Container); (Iterator) != end(Container); ++(Iterator) )
#define ramfor(Iterator, Container) for ( auto Iterator = Container.rbegin(); (Iterator) != Container.rend(); ++(Iterator) )
template<class C, class E> inline bool contains(const C& container, const E& element) { return container.find(element) != container.end(); }
#define  NP(nn,ta,a,tb,b) struct nn : pair<ta,tb> { nn():pair<ta,tb>(){}; nn(ta pa,tb pb):pair<ta,tb>(pa,pb){} ta& a(){return first;} tb& b(){return second;} };
template<class T> inline void checkmin(T &a, T b) { if (b < a) a = b; }//asigna en a el minimo
template<class T> inline void checkmax(T &a, T b) { if (b > a) a = b; }//asigna en a el maximo


using namespace std; // since cin and cout are both in namespace std, this saves some text

typedef long long ll;
int totalCases;
int theCase;
void Solve(ll n,ll k,ll &r1,ll &r2)
{
	ll minS = n;
	ll totInt = 1;
	ll minSCount = 1;
	while (k > totInt)
	{///parto todos los invtervalos al medio
		//Parto los chicos
		if (minS % 2 == 0)
		{//par
			minS = (minS - 1) / 2;
			///minSCount = minSCount;
		}
		else
		{//impar
			minS = (minS - 1) / 2;
			minSCount = minSCount*2 + totInt-minSCount;
		}
		k -= totInt;
		totInt *= 2;
	}
	ll maxS = minS + 1;
	ll maxSCount = totInt - minSCount;
	ll res;
	if (k <= maxSCount)
		res = maxS;
	else
		res = minS;
	r1 = (res / 2);
	r2 = (res - 1) / 2;
}

int main()
{
	cin >> totalCases;
	cout << std::setprecision(15);
	cout << std::fixed;
	for(theCase = 0;theCase <totalCases;theCase++)
	{
		cerr << theCase << endl;
		cout << "Case #" << theCase + 1 << ": ";
		ll n, k;
		cin >> n >> k;
		ll r1, r2;
		Solve(n,k,r1,r2);
		cout << r1 << " " << r2;
		cout << endl;
	}

	return 0;
}
