#include <iostream>
#include <vector>
#include <cstdio>
#include <sstream>
#include <map>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
#include <functional>
#include <set>
#include <ctime>
#include <random>
#include <chrono>
#include <cassert>
#include <tuple>
#include <utility>
using namespace std;

namespace {
  using Integer = long long; //__int128;
  template<class T, class S> istream& operator >> (istream& is, pair<T,S>& p){return is >> p.first >> p.second;}
  template<class T> istream& operator >> (istream& is, vector<T>& vec){for(T& val: vec) is >> val; return is;}
  template<class T> istream& operator ,  (istream& is, T& val){ return is >> val;}
  template<class T, class S> ostream& operator << (ostream& os, const pair<T,S>& p){return os << p.first << " " << p.second;}
  template<class T> ostream& operator << (ostream& os, const vector<T>& vec){for(size_t i=0; i<vec.size(); i++) os << vec[i] << (i==vec.size()-1?"":" "); return os;}
  template<class T> ostream& operator ,  (ostream& os, const T& val){ return os << " " << val;}

  template<class H> void print(const H& head){ cout << head; }
  template<class H, class ... T> void print(const H& head, const T& ... tail){ cout << head << " "; print(tail...); }
  template<class ... T> void println(const T& ... values){ print(values...); cout << endl; }

  template<class H> void eprint(const H& head){ cerr << head; }
  template<class H, class ... T> void eprint(const H& head, const T& ... tail){ cerr << head << " "; eprint(tail...); }
  template<class ... T> void eprintln(const T& ... values){ eprint(values...); cerr << endl; }

  class range{ Integer start_, end_, step_; public: struct range_iterator{ Integer val, step_; range_iterator(Integer v, Integer step) : val(v), step_(step) {} Integer operator * (){return val;} void operator ++ (){val += step_;} bool operator != (range_iterator& x){return step_ > 0 ? val < x.val : val > x.val;} }; range(Integer len) : start_(0), end_(len), step_(1) {} range(Integer start, Integer end) : start_(start), end_(end), step_(1) {} range(Integer start, Integer end, Integer step) : start_(start), end_(end), step_(step) {} range_iterator begin(){ return range_iterator(start_, step_); } range_iterator   end(){ return range_iterator(  end_, step_); } };

  inline string operator "" _s (const char* str, size_t size){ return move(string(str)); }
  constexpr Integer my_pow(Integer x, Integer k, Integer z=1){return k==0 ? z : k==1 ? z*x : (k&1) ? my_pow(x*x,k>>1,z*x) : my_pow(x*x,k>>1,z);}
  constexpr Integer my_pow_mod(Integer x, Integer k, Integer M, Integer z=1){return k==0 ? z%M : k==1 ? z*x%M : (k&1) ? my_pow_mod(x*x%M,k>>1,M,z*x%M) : my_pow_mod(x*x%M,k>>1,M,z);}
  constexpr unsigned long long operator "" _ten (unsigned long long value){ return my_pow(10,value); }

  inline int k_bit(Integer x, int k){return (x>>k)&1;} //0-indexed

  mt19937 mt(chrono::duration_cast<chrono::nanoseconds>(chrono::steady_clock::now().time_since_epoch()).count());

  template<class T> string join(const vector<T>& v, const string& sep){ stringstream ss; for(size_t i=0; i<v.size(); i++){ if(i>0) ss << sep; ss << v[i]; } return ss.str(); }

  inline string operator * (string s, int k){ string ret; while(k){ if(k&1) ret += s; s += s; k >>= 1; } return ret; }
}
constexpr long long mod = 9_ten + 7;

#ifdef LOCAL_TEST
pair<int,int> query(int y, int x){
  static mt19937 mt(123);
  static uniform_int_distribution<int> dstr(-1, 1);
  return {dstr(mt), dstr(mt)};
}
#else
pair<int,int> query(int y, int x){
  x += 10;
  y += 10;
  println(y,x);
  int yy, xx;
  cin >> yy, xx;

  if(yy == 0 && xx == 0){
    return {-100, -100};
  }else if(yy == -1 && xx == -1){
    eprintln("WA");
    abort();
    return {-100, -100};
  }else{
    yy -= y;
    xx -= x;
    return {yy,xx};
  }
}
#endif

void dbg(vector<vector<int>>& w){
#ifdef LOCAL_TEST
  static int turn = 0;
  int cnt = 0;
  for(int i=0; i<3; i++){
    string tmp;
    for(int j=0; j<w[i].size(); j++){
      tmp += w[i][j] ? '#' : '.';
      cnt += w[i][j];
    }
    eprintln(tmp);
  }
  turn++;
  eprintln("count : ", cnt);
  eprintln("turn  : ", turn);
#endif
}

int getCount(vector<vector<int>>& w, int c){
  int res = 0;
  for(int y=-1; y<=1; y++) for(int x=c-1; x<=c+1; x++){
    res += w[y+1][x];
  }
  return res;
}

void solve(){
  int a;
  cin >> a;

  vector<vector<int>> w(3, vector<int>(67, 0));
  set< pair<int,int> > cnt;
  for(int i=1; i<=65; i++){
    cnt.insert( {0, i} );
  }

  int t = 0;
  while( cnt.size() ){
    t++;
    auto c = cnt.begin() -> second;

    auto res = query(0, c);
    if( res == pair<int,int>{-100, -100} ) break;

    for(int i=max(1, c-2); i<=min(65, c+2); i++){
      int tmp = getCount(w, i);
      cnt.erase( pair<int,int>{tmp, i} );
    }

    w[res.first+1][c+res.second] = 1;

    for(int i=max(1, c-2); i<=min(65, c+2); i++){
      int tmp = getCount(w, i);
      if( tmp == 9 ) continue;
      cnt.insert( pair<int,int>{tmp, i} );
    }

    dbg(w);
  }

  eprintln(t);
}

int main(){
  int t;
  cin >> t;
  for(int i=0; i<t; i++){
    // printf("Case #%d: ", i+1);
    solve();
  }

  return 0;
}
