#include <bits/stdc++.h>
using namespace std;
typedef signed long long ll;

#undef _P
#define _P(...) (void)printf(__VA_ARGS__)
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define REP(i, n) FOR(i, 0, n)
#define FORR(x, arr) for (auto& x : arr)
#define ITR(x, c) for (__typeof(c.begin()) x = c.begin(); x != c.end(); x++)
#define ALL(a) (a.begin()), (a.end())
#define ZERO(a) memset(a, 0, sizeof(a))
#define MINUS(a) memset(a, 0xff, sizeof(a))
//-------------------------------------------------------

void solve() {
    int T;
    cin >> T;
    REP(i, T) {
        int a, b, N;
        cin >> a >> b >> N;

        REP(j, N) {
            string res;
            int mid = (a + b) / 2;
            cout << mid << endl << flush;
            cin >> res;

            if (res == "CORRECT") {
                break;
            }

            if (res == "TOO_SMALL") {
                a = mid + 1;
            } else {
                b = mid;
            }
        }
    }
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}
