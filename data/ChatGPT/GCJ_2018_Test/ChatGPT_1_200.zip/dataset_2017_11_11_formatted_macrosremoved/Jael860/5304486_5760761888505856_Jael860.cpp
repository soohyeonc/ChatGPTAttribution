#include <bits/stdc++.h>
using namespace std;
typedef signed long long ll;

#undef _P
#define _P(...) (void)printf(__VA_ARGS__)
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define REP(i, n) FOR(i, 0, n)
#define FORR(x, arr) for (auto& x : arr)
#define ITR(x, c) for (__typeof(c.begin()) x = c.begin(); x != c.end(); x++)
#define ALL(a) (a.begin()), (a.end())
#define ZERO(a) memset(a, 0, sizeof(a))
#define MINUS(a) memset(a, 0xff, sizeof(a))
//-------------------------------------------------------

pair<ll, ll> f(ll n, ll x) {
    if (x == 1) {
        return make_pair(n / 2, (n - 1) / 2);
    }

    bool b1 = n % 2 == 0;
    bool b2 = (x - 1) % 2 == 0;

    if (b1 && b2) {
        return f((n - 1) / 2, (x - 1) / 2);
    }

    if (!b1 && b2) {
        return f(n / 2, x / 2);
    }

    if (b1 && !b2) {
        return f(n / 2, x / 2);
    }

    if (!b1 && !b2) {
        return f(n / 2, x / 2);
    }
}

int T;

void solve() {
    cin >> T;
    REP(i, T) {
        ll N, K;
        cin >> N >> K;
        auto ans = f(N, K);
        _P("Case #%d: %lld %lld\n", i + 1, ans.first, ans.second);
    }
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}
