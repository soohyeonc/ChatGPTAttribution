#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 4000000000000000000LL
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


int main(int argc, char** argv)
{
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  std::cout << std::fixed << std::setprecision(9);
  std::cerr << std::fixed << std::setprecision(6);

  int T, D, N, K[1111], S[1111];

  std::cin >> T;

  for (int t = 1; t <= T; t ++) {
    std::cin >> D >> N;

    for (int i = 0; i < N; i ++)
      std::cin >> K[i] >> S[i];

    long double l = 1e-9, u = 1e+30;

    for (int i = 0; i < 512; i ++) {
      long double m = (l + u) / 2.0, t = D / m;

      bool valid = true;

      for (int j = 0; j < N; j ++) {
        double x = S[j] * t + K[j];

        if (x < D) {
          valid = false;

          break;
        }
      }

      (valid ? l : u) = m;
    }

    std::cout << "Case #" << t << ": " << l << std::endl;
  }

  return 0;
}
